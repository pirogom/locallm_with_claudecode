import React, { createContext, useState, useCallback, useEffect, ReactNode, useContext } from 'react';

// 타입 정의
export interface User {
  id: string;
  email: string;
  name: string;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

// 가짜 인증 API
const fakeAuth = {
  login: async (credentials: LoginCredentials): Promise<User> => {
    const validEmail = 'user@example.com';
    const validPassword = 'password123';

    await new Promise(resolve => setTimeout(resolve, 800));

    if (credentials.email === validEmail && credentials.password === validPassword) {
      return {
        id: '1',
        email: credentials.email,
        name: 'Test User',
      };
    }

    throw new Error('이메일 또는 비밀번호가 일치하지 않습니다.');
  },

  logout: async (): Promise<void> => {
    await new Promise(resolve => setTimeout(resolve, 300));
  },

  updateProfile: async (updates: Partial<User>): Promise<User> => {
    await new Promise(resolve => setTimeout(resolve, 500));

    if (updates.name !== undefined && !updates.name.trim()) {
      throw new Error('이름을 입력해주세요.');
    }
    if (updates.email !== undefined && !updates.email.trim()) {
      throw new Error('이메일을 입력해주세요.');
    }
    if (updates.email !== undefined) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(updates.email)) {
        throw new Error('올바른 이메일 형식이 아닙니다.');
      }
    }

    return updates as User;
  },
};

// localStorage 래퍼
const authStorage = {
  getUser: (): User | null => {
    try {
      const stored = localStorage.getItem('user');
      return stored ? JSON.parse(stored) : null;
    } catch {
      localStorage.removeItem('user');
      return null;
    }
  },

  setUser: (user: User): void => {
    localStorage.setItem('user', JSON.stringify(user));
  },

  removeUser: (): void => {
    localStorage.removeItem('user');
  },
};

// 컨텍스트 타입
interface AuthContextType extends AuthState {
  login: (credentials: LoginCredentials) => Promise<void>;
  logout: () => Promise<void>;
  updateProfile: (user: Partial<User>) => Promise<void>;
  clearError: () => void;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    isLoading: true,
    error: null,
  });

  useEffect(() => {
    const storedUser = authStorage.getUser();
    if (storedUser) {
      setAuthState({
        user: storedUser,
        isAuthenticated: true,
        isLoading: false,
        error: null,
      });
    } else {
      setAuthState(prev => ({ ...prev, isLoading: false }));
    }
  }, []);

  const login = useCallback(async (credentials: LoginCredentials) => {
    setAuthState(prev => ({ ...prev, isLoading: true, error: null }));

    try {
      const user = await fakeAuth.login(credentials);
      authStorage.setUser(user);
      setAuthState({
        user,
        isAuthenticated: true,
        isLoading: false,
        error: null,
      });
    } catch (err) {
      setAuthState(prev => ({
        ...prev,
        isLoading: false,
        error: err instanceof Error ? err.message : '로그인 실패',
      }));
    }
  }, []);

  const logout = useCallback(async () => {
    setAuthState(prev => ({ ...prev, isLoading: true }));
    await fakeAuth.logout();
    authStorage.removeUser();
    setAuthState({
      user: null,
      isAuthenticated: false,
      isLoading: false,
      error: null,
    });
  }, []);

  const updateProfile = useCallback(async (updates: Partial<User>) => {
    setAuthState(prev => ({ ...prev, isLoading: true, error: null }));

    try {
      const user = await fakeAuth.updateProfile(updates as User);
      authStorage.setUser(user);
      setAuthState(prev => ({
        ...prev,
        user,
        isLoading: false,
      }));
    } catch (err) {
      setAuthState(prev => ({
        ...prev,
        isLoading: false,
        error: err instanceof Error ? err.message : '프로필 수정 실패',
      }));
      throw err;
    }
  }, []);

  const clearError = useCallback(() => {
    setAuthState(prev => ({ ...prev, error: null }));
  }, []);

  return (
    <AuthContext.Provider value={{ ...authState, login, logout, updateProfile, clearError }}>
      {children}
    </AuthContext.Provider>
  );
};

// useAuth 훅
export const useAuth = () => {
  const context = useContext(AuthContext);

  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }

  return context;
};
