import React, { useState, useEffect, useCallback, useRef } from 'react';

const GRID_SIZE = 20;
const CELL_SIZE = 20;
const INITIAL_SPEED = 150;

type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';
type Position = { x: number; y: number };

const getRandomPosition = (): Position => ({
  x: Math.floor(Math.random() * GRID_SIZE),
  y: Math.floor(Math.random() * GRID_SIZE),
});

export const SnakeGamePage: React.FC = () => {
  const [snake, setSnake] = useState<Position[]>([{ x: 10, y: 10 }]);
  const [food, setFood] = useState<Position>(getRandomPosition());
  const [direction, setDirection] = useState<Direction>('RIGHT');
  const [gameOver, setGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const directionRef = useRef(direction);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const resetGame = useCallback(() => {
    setSnake([{ x: 10, y: 10 }]);
    setFood(getRandomPosition());
    setDirection('RIGHT');
    directionRef.current = 'RIGHT';
    setGameOver(false);
    setScore(0);
    setIsPlaying(true);
  }, []);

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    const key = e.key;
    const current = directionRef.current;

    if (key === 'ArrowUp' && current !== 'DOWN') {
      directionRef.current = 'UP';
    } else if (key === 'ArrowDown' && current !== 'UP') {
      directionRef.current = 'DOWN';
    } else if (key === 'ArrowLeft' && current !== 'RIGHT') {
      directionRef.current = 'LEFT';
    } else if (key === 'ArrowRight' && current !== 'LEFT') {
      directionRef.current = 'RIGHT';
    }
  }, []);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  // Canvas 렌더링
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // 배경 지우기
    ctx.fillStyle = '#0f0f23';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // 먹이 그리기
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(food.x * CELL_SIZE, food.y * CELL_SIZE, CELL_SIZE - 2, CELL_SIZE - 2);

    // 뱀 그리기
    snake.forEach((segment, index) => {
      ctx.fillStyle = index === 0 ? '#4ade80' : '#22c55e';
      ctx.fillRect(segment.x * CELL_SIZE, segment.y * CELL_SIZE, CELL_SIZE - 2, CELL_SIZE - 2);
    });
  }, [snake, food]);

  useEffect(() => {
    if (!isPlaying || gameOver) return;

    const moveSnake = () => {
      setDirection(directionRef.current);

      setSnake(prevSnake => {
        const head = { ...prevSnake[0] };
        const currentDirection = directionRef.current;

        if (currentDirection === 'UP') head.y -= 1;
        if (currentDirection === 'DOWN') head.y += 1;
        if (currentDirection === 'LEFT') head.x -= 1;
        if (currentDirection === 'RIGHT') head.x += 1;

        // 벽 충돌 검사
        if (head.x < 0 || head.x >= GRID_SIZE || head.y < 0 || head.y >= GRID_SIZE) {
          setGameOver(true);
          setIsPlaying(false);
          return prevSnake;
        }

        // 자기 자신과 충돌 검사
        if (prevSnake.some(segment => segment.x === head.x && segment.y === head.y)) {
          setGameOver(true);
          setIsPlaying(false);
          return prevSnake;
        }

        const newSnake = [head, ...prevSnake];

        // 먹이 먹기
        if (head.x === food.x && head.y === food.y) {
          setScore(s => s + 10);
          setFood(getRandomPosition());
        } else {
          newSnake.pop();
        }

        return newSnake;
      });
    };

    const gameLoop = setInterval(moveSnake, INITIAL_SPEED);
    return () => clearInterval(gameLoop);
  }, [isPlaying, gameOver, food]);

  return (
    <div style={{
      minHeight: '100vh',
      backgroundColor: '#1a1a2e',
      color: '#eee',
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
    }}>
      <h1 style={{ marginBottom: '10px' }}>🐍 스네이크 게임</h1>

      <div style={{ marginBottom: '20px', fontSize: '24px' }}>
        점수: <strong style={{ color: '#4ade80' }}>{score}</strong>
      </div>

      <canvas
        ref={canvasRef}
        width={GRID_SIZE * CELL_SIZE}
        height={GRID_SIZE * CELL_SIZE}
        style={{
          border: '2px solid #444',
          backgroundColor: '#0f0f23',
        }}
      />

      <div style={{ marginTop: '20px', display: 'flex', gap: '10px' }}>
        {!isPlaying && !gameOver && (
          <button
            onClick={resetGame}
            style={{
              padding: '12px 24px',
              fontSize: '18px',
              backgroundColor: '#4ade80',
              color: '#000',
              border: 'none',
              borderRadius: '8px',
              cursor: 'pointer',
              fontWeight: 'bold',
            }}
          >
            게임 시작
          </button>
        )}

        {gameOver && (
          <button
            onClick={resetGame}
            style={{
              padding: '12px 24px',
              fontSize: '18px',
              backgroundColor: '#f87171',
              color: '#fff',
              border: 'none',
              borderRadius: '8px',
              cursor: 'pointer',
              fontWeight: 'bold',
            }}
          >
            다시 하기
          </button>
        )}

        {isPlaying && (
          <button
            onClick={() => setIsPlaying(false)}
            style={{
              padding: '12px 24px',
              fontSize: '18px',
              backgroundColor: '#fbbf24',
              color: '#000',
              border: 'none',
              borderRadius: '8px',
              cursor: 'pointer',
              fontWeight: 'bold',
            }}
          >
            일시정지
          </button>
        )}

        {!isPlaying && !gameOver && snake.length > 1 && (
          <button
            onClick={() => setIsPlaying(true)}
            style={{
              padding: '12px 24px',
              fontSize: '18px',
              backgroundColor: '#60a5fa',
              color: '#fff',
              border: 'none',
              borderRadius: '8px',
              cursor: 'pointer',
              fontWeight: 'bold',
            }}
          >
            계속하기
          </button>
        )}
      </div>

      {gameOver && (
        <div style={{ marginTop: '20px', color: '#f87171', fontSize: '20px' }}>
          게임 오버! 최종 점수: {score}
        </div>
      )}

      {!isPlaying && !gameOver && snake.length === 1 && (
        <div style={{ marginTop: '20px', color: '#888' }}>
          "게임 시작" 버튼을 누르세요
        </div>
      )}

      {/* 규칙 및 조작법 */}
      <div style={{
        marginTop: '30px',
        padding: '20px',
        backgroundColor: '#16213e',
        borderRadius: '8px',
        maxWidth: '500px',
      }}>
        <h2 style={{ marginBottom: '15px', color: '#4ade80' }}>📖 게임 규칙</h2>
        <ul style={{ lineHeight: '1.8', margin: 0, paddingLeft: '20px' }}>
          <li>뱀을 움직여 먹이 (흰색) 를 먹으세요</li>
          <li>먹이를 먹을 때마다 뱀이 길어지고 점수가 오릅니다</li>
          <li>벽이나 자신의 몸에 부딪히면 게임 오버입니다</li>
        </ul>

        <h2 style={{ marginTop: '20px', marginBottom: '15px', color: '#60a5fa' }}>🎮 조작법</h2>
        <ul style={{ lineHeight: '1.8', margin: 0, paddingLeft: '20px' }}>
          <li>↑ 위쪽 화살표: 위로 이동</li>
          <li>↓ 아래쪽 화살표: 아래로 이동</li>
          <li>← 왼쪽 화살표: 왼쪽으로 이동</li>
          <li>→ 오른쪽 화살표: 오른쪽으로 이동</li>
        </ul>
      </div>

      </div>
  );
};
