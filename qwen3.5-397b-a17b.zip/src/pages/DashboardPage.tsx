import React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

export const DashboardPage: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/login', { replace: true });
  };

  return (
    <div style={{
      minHeight: '100vh',
      backgroundColor: '#f5f5f5',
    }}>
      {/* 헤더 */}
      <header style={{
        backgroundColor: 'white',
        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
        padding: '16px 24px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
      }}>
        <h1 style={{
          margin: 0,
          fontSize: '24px',
          color: '#333',
        }}>
          대시보드
        </h1>
        <div style={{ display: 'flex', gap: '12px' }}>
          <Link
            to="/profile"
            style={{
              padding: '10px 20px',
              backgroundColor: '#007bff',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              fontSize: '14px',
              fontWeight: 500,
              cursor: 'pointer',
              textDecoration: 'none',
              textAlign: 'center',
            }}
          >
            프로필
          </Link>
          <button
            onClick={handleLogout}
            style={{
              padding: '10px 20px',
              backgroundColor: '#dc3545',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              fontSize: '14px',
              fontWeight: 500,
              cursor: 'pointer',
            }}
          >
            로그아웃
          </button>
        </div>
      </header>

      {/* 메인 콘텐츠 */}
      <main style={{
        padding: '24px',
        maxWidth: '1200px',
        margin: '0 auto',
      }}>
        {/* 환영 메시지 */}
        <div style={{
          backgroundColor: 'white',
          padding: '24px',
          borderRadius: '8px',
          boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
          marginBottom: '24px',
        }}>
          <h2 style={{
            margin: '0 0 8px 0',
            color: '#333',
          }}>
            환영합니다, {user?.name}님!
          </h2>
          <p style={{
            margin: 0,
            color: '#666',
          }}>
            이메일: {user?.email}
          </p>
        </div>

        {/* 대시보드 카드들 */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
          gap: '20px',
        }}>
          <div style={{
            backgroundColor: 'white',
            padding: '24px',
            borderRadius: '8px',
            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
          }}>
            <h3 style={{
              margin: '0 0 12px 0',
              color: '#007bff',
              fontSize: '18px',
            }}>
              프로젝트
            </h3>
            <p style={{
              margin: 0,
              fontSize: '32px',
              fontWeight: 'bold',
              color: '#333',
            }}>
              12
            </p>
            <p style={{
              margin: '8px 0 0 0',
              color: '#666',
              fontSize: '14px',
            }}>
              활성 프로젝트
            </p>
          </div>

          <div style={{
            backgroundColor: 'white',
            padding: '24px',
            borderRadius: '8px',
            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
          }}>
            <h3 style={{
              margin: '0 0 12px 0',
              color: '#28a745',
              fontSize: '18px',
            }}>
              작업
            </h3>
            <p style={{
              margin: 0,
              fontSize: '32px',
              fontWeight: 'bold',
              color: '#333',
            }}>
              48
            </p>
            <p style={{
              margin: '8px 0 0 0',
              color: '#666',
              fontSize: '14px',
            }}>
              진행 중인 작업
            </p>
          </div>

          <div style={{
            backgroundColor: 'white',
            padding: '24px',
            borderRadius: '8px',
            boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)',
          }}>
            <h3 style={{
              margin: '0 0 12px 0',
              color: '#ffc107',
              fontSize: '18px',
            }}>
              알림
            </h3>
            <p style={{
              margin: 0,
              fontSize: '32px',
              fontWeight: 'bold',
              color: '#333',
            }}>
              5
            </p>
            <p style={{
              margin: '8px 0 0 0',
              color: '#666',
              fontSize: '14px',
            }}>
              새 알림
            </p>
          </div>
        </div>

        {/* 보호된 라우트 정보 */}
        <div style={{
          marginTop: '24px',
          padding: '20px',
          backgroundColor: '#e7f3ff',
          borderRadius: '8px',
          border: '1px solid #b6d4fe',
        }}>
          <h3 style={{
            margin: '0 0 12px 0',
            color: '#084298',
          }}>
            🔒 보호된 라우트
          </h3>
          <p style={{
            margin: 0,
            color: '#084298',
            lineHeight: 1.6,
          }}>
            이 페이지는 인증된 사용자만 접근할 수 있습니다.<br />
            로그아웃 후 뒤로가기를 하거나 직접 URL 을 입력하면 로그인 페이지로 리다이렉트됩니다.
          </p>
        </div>
      </main>
    </div>
  );
};
