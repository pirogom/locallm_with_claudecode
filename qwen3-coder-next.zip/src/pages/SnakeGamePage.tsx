import { useState, useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'

// 게임 설정
const GRID_SIZE = 20
const INITIAL_SPEED = 150
const MIN_SPEED = 80
const SPEED_DECREMENT = 5
const WALL_BUFFER = 1 // 벽에서 떨어진 버퍼 영역

type Point = { x: number; y: number }
type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT'
type GameStatus = 'IDLE' | 'PLAYING' | 'PAUSED' | 'GAME_OVER'

export default function SnakeGamePage() {
  const [snake, setSnake] = useState<Point[]>([{ x: 10, y: 10 }])
  const [food, setFood] = useState<Point>({ x: 15, y: 5 })
  const [direction, setDirection] = useState<Direction>('RIGHT')
  const [nextDirection, setNextDirection] = useState<Direction>('RIGHT')
  const [status, setStatus] = useState<GameStatus>('IDLE')
  const [score, setScore] = useState(0)
  const [highScore, setHighScore] = useState(0)
  const [speed, setSpeed] = useState(INITIAL_SPEED)

  const requestAnimationFrameRef = useRef<number | null>(null)
  const snakeRef = useRef<Point[]>([{ x: 10, y: 10 }])
  const foodRef = useRef<Point>({ x: 15, y: 5 })
  const directionRef = useRef<Direction>('RIGHT')
  const nextDirectionRef = useRef<Direction>('RIGHT')
  const statusRef = useRef<GameStatus>('IDLE')
  const scoreRef = useRef(0)
  const highScoreRef = useRef(0)
  const speedRef = useRef(INITIAL_SPEED)
  const lastTimeRef = useRef<number>(0)
  const navigate = useNavigate()

  // 게임 중에는 state-to-ref 동기화를 비활성화하는 플래그
  const isGameActiveRef = useRef(false)

  // Ref 업데이트 - 게임 중에는 상태를 ref에 동기화하지 않음
  // 게임 시작 시점의 ref 값이 계속 사용됨
  useEffect(() => {
    if (!isGameActiveRef.current) {
      snakeRef.current = snake
    }
  }, [snake])

  useEffect(() => {
    if (!isGameActiveRef.current) {
      foodRef.current = food
    }
  }, [food])

  useEffect(() => {
    if (!isGameActiveRef.current) {
      directionRef.current = direction
    }
  }, [direction])

  useEffect(() => {
    if (!isGameActiveRef.current) {
      nextDirectionRef.current = nextDirection
    }
  }, [nextDirection])

  useEffect(() => {
    statusRef.current = status
  }, [status])

  useEffect(() => {
    if (!isGameActiveRef.current) {
      scoreRef.current = score
    }
  }, [score])

  useEffect(() => {
    if (!isGameActiveRef.current) {
      highScoreRef.current = highScore
    }
  }, [highScore])

  useEffect(() => {
    if (!isGameActiveRef.current) {
      speedRef.current = speed
    }
  }, [speed])

  // 하이스코어 로드
  useEffect(() => {
    const saved = localStorage.getItem('snakeHighScore')
    if (saved) {
      const score = parseInt(saved, 10)
      setHighScore(score)
      highScoreRef.current = score
    }
  }, [])

  // 게임 루프 - requestAnimationFrame 사용
  useEffect(() => {
    console.log('[GameLoop] status:', status, 'speed:', speed)

    if (status === 'PLAYING') {
      // 게임 시작 시 isGameActiveRef를 true로 설정하여 state-to-ref 동기화 비활성화
      isGameActiveRef.current = true
      lastTimeRef.current = performance.now()
      console.log('[GameLoop] Starting animation frame with gameLoop:', typeof gameLoop)
      // 게임 루프 시작 - 즉시 실행
      requestAnimationFrameRef.current = requestAnimationFrame(gameLoop)
    } else {
      if (requestAnimationFrameRef.current) {
        console.log('[GameLoop] Cancelling animation frame')
        cancelAnimationFrame(requestAnimationFrameRef.current)
        requestAnimationFrameRef.current = null
      }
      // 게임 종료 시 isGameActiveRef를 false로 설정하여 state-to-ref 동기화 활성화
      isGameActiveRef.current = false
    }

    return () => {
      if (requestAnimationFrameRef.current) {
        console.log('[GameLoop] Cleaning up animation frame')
        cancelAnimationFrame(requestAnimationFrameRef.current)
      }
      // 정리 시 isGameActiveRef를 false로 설정
      isGameActiveRef.current = false
    }
  }, [status, speed])

  // 게임 루프 함수 - 일반 함수로 정의하여 stale closure 문제 방지
  const gameLoop = (time: number) => {
    // statusRef.current를 사용하여 항상 최신 상태 읽기
    if (statusRef.current !== 'PLAYING') {
      console.log('[gameLoop] Game not playing, stopping')
      return
    }

    // 속도에 따라 프레임 스킵
    const elapsed = time - lastTimeRef.current
    const currentSpeed = speedRef.current

    if (elapsed < currentSpeed) {
      requestAnimationFrameRef.current = requestAnimationFrame(gameLoop)
      return
    }

    lastTimeRef.current = time

    // 현재 상태 사용 - ref를 통해 항상 최신 값 읽기
    const currentSnake = [...snakeRef.current]
    const currentFood = { ...foodRef.current }
    const currentDirection = directionRef.current
    const currentNextDirection = nextDirectionRef.current
    const currentScore = scoreRef.current
    const currentHighScore = highScoreRef.current
    const gameSpeed = speedRef.current

    // 방향 업데이트 (반대 방향은 제외)
    let validDirection = currentDirection
    if (currentNextDirection !== currentDirection) {
      const isOpposite =
        (currentNextDirection === 'UP' && currentDirection === 'DOWN') ||
        (currentNextDirection === 'DOWN' && currentDirection === 'UP') ||
        (currentNextDirection === 'LEFT' && currentDirection === 'RIGHT') ||
        (currentNextDirection === 'RIGHT' && currentDirection === 'LEFT')
      if (!isOpposite) {
        validDirection = currentNextDirection
      }
    }

    console.log(`[gameLoop] Snake head: (${currentSnake[0].x}, ${currentSnake[0].y}), Food: (${currentFood.x}, ${currentFood.y}), Direction: ${currentDirection}, NextDirection: ${currentNextDirection}, ValidDirection: ${validDirection}`)

    const head = currentSnake[0]
    const newHead = { ...head }

    switch (validDirection) {
      case 'UP':
        newHead.y -= 1
        break
      case 'DOWN':
        newHead.y += 1
        break
      case 'LEFT':
        newHead.x -= 1
        break
      case 'RIGHT':
        newHead.x += 1
        break
    }

    // 벽 충돌 확인
    if (
      newHead.x < 0 ||
      newHead.x >= GRID_SIZE ||
      newHead.y < 0 ||
      newHead.y >= GRID_SIZE
    ) {
      console.log('[gameLoop] Wall collision!')
      setStatus('GAME_OVER')
      return
    }

    // 자기 충돌 확인
    if (currentSnake.some((segment, idx) => idx !== 0 && segment.x === newHead.x && segment.y === newHead.y)) {
      console.log('[gameLoop] Self collision!')
      setStatus('GAME_OVER')
      return
    }

    const newSnake = [newHead, ...currentSnake]

    // 음식 먹기
    if (newHead.x === currentFood.x && newHead.y === currentFood.y) {
      const newScore = currentScore + 10
      if (newScore > currentHighScore) {
        highScoreRef.current = newScore
        setHighScore(newScore)
        localStorage.setItem('snakeHighScore', newScore.toString())
      }

      // 새로운 음식 생성
      let newFood: Point
      do {
        newFood = {
          x: Math.floor(Math.random() * GRID_SIZE),
          y: Math.floor(Math.random() * GRID_SIZE),
        }
      } while (newSnake.some(s => s.x === newFood.x && s.y === newFood.y))

      // ref를 먼저 업데이트하고 상태 업데이트
      snakeRef.current = newSnake
      foodRef.current = newFood
      setSnake(newSnake)
      setFood(newFood)
      setScore(newScore)
      setSpeed(Math.max(MIN_SPEED, gameSpeed - SPEED_DECREMENT))
    } else {
      newSnake.pop() // 꼬리 제거
      // ref를 먼저 업데이트하고 상태 업데이트
      snakeRef.current = newSnake
      setSnake(newSnake)
    }

    // 방향 업데이트
    if (validDirection !== currentDirection) {
      directionRef.current = validDirection
      setDirection(validDirection)
    }

    // 다음 프레임 요청 - gameLoop 직접 재귀 호출
    requestAnimationFrameRef.current = requestAnimationFrame(gameLoop)
  }

  const startGame = () => {
    console.log('[startGame] Starting game...')
    // 초기 뱀 위치는 중앙-왼쪽 쪽 (Wall Buffer 고려)
    const initialSnake = [{ x: 5, y: 10 }]
    // 초기 음식 생성 (snake와 겹치지 않도록)
    let initialFood: Point
    do {
      initialFood = {
        x: Math.floor(Math.random() * (GRID_SIZE - WALL_BUFFER * 2)) + WALL_BUFFER,
        y: Math.floor(Math.random() * (GRID_SIZE - WALL_BUFFER * 2)) + WALL_BUFFER,
      }
    } while (initialFood.x === initialSnake[0].x && initialFood.y === initialSnake[0].y)

    console.log('[startGame] Setting ref and state...')
    // 게임 중에는 state-to-ref 동기화가 비활성화되므로 ref를 먼저 설정
    isGameActiveRef.current = true
    snakeRef.current = initialSnake
    foodRef.current = initialFood
    directionRef.current = 'RIGHT'
    nextDirectionRef.current = 'RIGHT'
    scoreRef.current = 0
    speedRef.current = INITIAL_SPEED

    // 상태 업데이트 - React batching으로 한 번에 실행됨
    setScore(0)
    setSpeed(INITIAL_SPEED)
    setSnake(initialSnake)
    setFood(initialFood)
    setDirection('RIGHT')
    setNextDirection('RIGHT')
    // status를 마지막으로 업데이트 - 게임 루프가 반응할 수 있도록
    setStatus('PLAYING')
    statusRef.current = 'PLAYING'
    console.log('[startGame] Game started! Snake:', initialSnake)
    console.log('[startGame] snakeRef.current:', snakeRef.current)
    console.log('[startGame] foodRef.current:', foodRef.current)
  }

  const pauseGame = () => {
    setStatus('PAUSED')
    statusRef.current = 'PAUSED'
  }

  const resumeGame = () => {
    setStatus('PLAYING')
    statusRef.current = 'PLAYING'
  }

  const resetGame = () => {
    setStatus('IDLE')
    statusRef.current = 'IDLE'
    // 게임 중에는 state-to-ref 동기화가 비활성화되어 있으므로 수동으로 ref 업데이트
    isGameActiveRef.current = false
    snakeRef.current = [{ x: 10, y: 10 }]
    foodRef.current = { x: 15, y: 5 }
    directionRef.current = 'RIGHT'
    nextDirectionRef.current = 'RIGHT'
    scoreRef.current = 0
    highScoreRef.current = highScore
    speedRef.current = INITIAL_SPEED
    // 상태도 재설정
    setSnake([{ x: 10, y: 10 }])
    setFood({ x: 15, y: 5 })
    setDirection('RIGHT')
    setNextDirection('RIGHT')
    setScore(0)
    setSpeed(INITIAL_SPEED)
  }

  // 디버깅: snake 상태 변경 콘솔 출력
  useEffect(() => {
    console.log('[DEBUG] snake updated:', snake)
    console.log('[DEBUG] food updated:', food)
    console.log('[DEBUG] status:', status)
  }, [snake, food, status])

  // 디버깅: nextDirection 변경 콘솔 출력
  useEffect(() => {
    console.log('[DEBUG] nextDirection updated:', nextDirection)
  }, [nextDirection])

  // 키보드 컨트롤 - ref를 사용하여 stale closure 문제 방지
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      console.log('[handleKeyDown] Key pressed:', e.key, 'Status:', statusRef.current)
      if (statusRef.current !== 'PLAYING') return

      switch (e.key) {
        case 'ArrowUp':
        case 'w':
        case 'W':
          console.log('[handleKeyDown] UP key pressed')
          if (directionRef.current !== 'DOWN') {
            setNextDirection('UP')
            nextDirectionRef.current = 'UP'
          }
          break
        case 'ArrowDown':
        case 's':
        case 'S':
          console.log('[handleKeyDown] DOWN key pressed')
          if (directionRef.current !== 'UP') {
            setNextDirection('DOWN')
            nextDirectionRef.current = 'DOWN'
          }
          break
        case 'ArrowLeft':
        case 'a':
        case 'A':
          console.log('[handleKeyDown] LEFT key pressed')
          if (directionRef.current !== 'RIGHT') {
            setNextDirection('LEFT')
            nextDirectionRef.current = 'LEFT'
          }
          break
        case 'ArrowRight':
        case 'd':
        case 'D':
          console.log('[handleKeyDown] RIGHT key pressed')
          if (directionRef.current !== 'LEFT') {
            setNextDirection('RIGHT')
            nextDirectionRef.current = 'RIGHT'
          }
          break
        case ' ':
          setStatus('PAUSED')
          statusRef.current = 'PAUSED'
          break
        case 'Escape':
          setStatus('IDLE')
          statusRef.current = 'IDLE'
          break
      }
    }

    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [])

  // 모바일 컨트롤 핸들러 - ref를 사용하여 즉시 업데이트
  const handleDirectionClick = (dir: Direction) => {
    if (statusRef.current !== 'PLAYING') return

    let shouldUpdate = false
    if (dir === 'UP' && directionRef.current !== 'DOWN') {
      setNextDirection('UP')
      nextDirectionRef.current = 'UP'
      shouldUpdate = true
    }
    if (dir === 'DOWN' && directionRef.current !== 'UP') {
      setNextDirection('DOWN')
      nextDirectionRef.current = 'DOWN'
      shouldUpdate = true
    }
    if (dir === 'LEFT' && directionRef.current !== 'RIGHT') {
      setNextDirection('LEFT')
      nextDirectionRef.current = 'LEFT'
      shouldUpdate = true
    }
    if (dir === 'RIGHT' && directionRef.current !== 'LEFT') {
      setNextDirection('RIGHT')
      nextDirectionRef.current = 'RIGHT'
      shouldUpdate = true
    }

    console.log('[handleDirectionClick] Direction:', dir, 'New NextDirection:', nextDirectionRef.current)
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Snake Game</h1>
          <p className="text-gray-600">Play as a guest - no login required!</p>
          <button
            onClick={() => navigate('/login')}
            className="mt-4 px-6 py-2 text-sm font-medium text-blue-600 hover:text-blue-700 hover:bg-blue-50 rounded-lg transition-colors"
          >
            Sign in to save your score
          </button>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Game Board */}
          <div className="flex flex-col items-center">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              {/* Score Board */}
              <div className="flex justify-between items-center mb-4 px-2">
                <div className="text-center">
                  <p className="text-sm text-gray-500">Score</p>
                  <p className="text-2xl font-bold text-gray-900">{score}</p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-gray-500">High Score</p>
                  <p className="text-2xl font-bold text-gray-900">{highScore}</p>
                </div>
              </div>

              {/* Game Grid */}
              <div
                className="grid"
                style={{
                  backgroundColor: '#e5e7eb',
                  borderRadius: '0.5rem',
                  overflow: 'hidden',
                  gridTemplateColumns: `repeat(${GRID_SIZE}, 24px)`,
                  gridTemplateRows: `repeat(${GRID_SIZE}, 24px)`,
                }}
              >
                {Array.from({ length: GRID_SIZE * GRID_SIZE }).map((_, i) => {
                  const x = i % GRID_SIZE
                  const y = Math.floor(i / GRID_SIZE)
                  const isSnakeHead = snake[0]?.x === x && snake[0]?.y === y
                  const isSnakeBody = snake.some((s, idx) => idx !== 0 && s.x === x && s.y === y)
                  const isFood = food.x === x && food.y === y

                  let cellStyle: React.CSSProperties = {
                    width: '24px',
                    height: '24px',
                    border: '1px solid #d1d5db',
                    backgroundColor: '#ffffff',
                  }

                  if (isSnakeHead) {
                    cellStyle.backgroundColor = '#16a34a' // green-600
                  } else if (isSnakeBody) {
                    cellStyle.backgroundColor = '#4ade80' // green-400
                  } else if (isFood) {
                    cellStyle.backgroundColor = '#ef4444' // red-500
                  }

                  return <div key={i} style={cellStyle} data-cell={`${x},${y}`} />
                })}
              </div>

              {/* Status Message */}
              <div className="mt-4 text-center">
                {status === 'IDLE' && (
                  <div className="p-4 bg-blue-50 rounded-lg text-blue-700">
                    Press <strong>Start Game</strong> to begin!
                  </div>
                )}
                {status === 'PLAYING' && (
                  <div className="text-green-600 font-medium">Game in progress...</div>
                )}
                {status === 'PAUSED' && (
                  <div className="p-4 bg-yellow-50 rounded-lg text-yellow-700">
                    Game paused. Press <strong>Resume</strong> to continue!
                  </div>
                )}
                {status === 'GAME_OVER' && (
                  <div className="p-4 bg-red-50 rounded-lg text-red-700">
                    Game Over! Final Score: <strong>{score}</strong>
                  </div>
                )}
              </div>

              {/* Controls */}
              <div className="mt-6 flex flex-wrap justify-center gap-3">
                {status === 'IDLE' && (
                  <button
                    onClick={startGame}
                    className="px-6 py-2 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 focus:ring-4 focus:ring-green-500/20 transition-all"
                  >
                    Start Game
                  </button>
                )}
                {status === 'PLAYING' && (
                  <button
                    onClick={pauseGame}
                    className="px-6 py-2 bg-yellow-600 text-white rounded-lg font-medium hover:bg-yellow-700 focus:ring-4 focus:ring-yellow-500/20 transition-all"
                  >
                    Pause (Space)
                  </button>
                )}
                {status === 'PAUSED' && (
                  <>
                    <button
                      onClick={resumeGame}
                      className="px-6 py-2 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 focus:ring-4 focus:ring-green-500/20 transition-all"
                    >
                      Resume (Space)
                    </button>
                    <button
                      onClick={resetGame}
                      className="px-6 py-2 bg-gray-600 text-white rounded-lg font-medium hover:bg-gray-700 focus:ring-4 focus:ring-gray-500/20 transition-all"
                    >
                      Reset
                    </button>
                  </>
                )}
                {status === 'GAME_OVER' && (
                  <button
                    onClick={startGame}
                    className="px-6 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 focus:ring-4 focus:ring-blue-500/20 transition-all"
                  >
                    Play Again
                  </button>
                )}
                <button
                  onClick={() => navigate('/')}
                  className="px-6 py-2 bg-gray-200 text-gray-700 rounded-lg font-medium hover:bg-gray-300 focus:ring-4 focus:ring-gray-500/20 transition-all"
                >
                  Back to Home
                </button>
              </div>
            </div>

            {/* Mobile Controls */}
            <div className="mt-6 grid grid-cols-3 gap-2 lg:hidden">
              <div />
              <button
                onClick={() => handleDirectionClick('UP')}
                className="w-16 h-16 bg-gray-200 rounded-lg active:bg-gray-300 flex items-center justify-center text-2xl font-bold"
              >
                ↑
              </button>
              <div />
              <button
                onClick={() => handleDirectionClick('LEFT')}
                className="w-16 h-16 bg-gray-200 rounded-lg active:bg-gray-300 flex items-center justify-center text-2xl font-bold"
              >
                ←
              </button>
              <button
                onClick={() => handleDirectionClick('DOWN')}
                className="w-16 h-16 bg-gray-200 rounded-lg active:bg-gray-300 flex items-center justify-center text-2xl font-bold"
              >
                ↓
              </button>
              <button
                onClick={() => handleDirectionClick('RIGHT')}
                className="w-16 h-16 bg-gray-200 rounded-lg active:bg-gray-300 flex items-center justify-center text-2xl font-bold"
              >
                →
              </button>
            </div>
          </div>

          {/* Rules and Instructions */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Game Rules</h2>

            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Objective</h3>
                <p className="text-gray-600 leading-relaxed">
                  Guide the snake to eat the red food blocks. Each food eaten increases
                  your score and makes the snake longer. Avoid hitting walls or your own
                  tail!
                </p>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Controls</h3>
                <ul className="space-y-2 text-gray-600">
                  <li className="flex items-center">
                    <kbd className="px-2 py-1 bg-gray-100 rounded border border-gray-300 font-mono text-sm mr-2">
                      ↑↓←→
                    </kbd>
                    <span>Move snake direction</span>
                  </li>
                  <li className="flex items-center">
                    <kbd className="px-2 py-1 bg-gray-100 rounded border border-gray-300 font-mono text-sm mr-2">
                      WASD
                    </kbd>
                    <span>Alternative movement keys</span>
                  </li>
                  <li className="flex items-center">
                    <kbd className="px-2 py-1 bg-gray-100 rounded border border-gray-300 font-mono text-sm mr-2">
                      Space
                    </kbd>
                    <span>Pause/Resume game</span>
                  </li>
                  <li className="flex items-center">
                    <kbd className="px-2 py-1 bg-gray-100 rounded border border-gray-300 font-mono text-sm mr-2">
                      Esc
                    </kbd>
                    <span>Exit to title screen</span>
                  </li>
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-gray-800 mb-2">Scoring</h3>
                <ul className="space-y-2 text-gray-600">
                  <li>• Each food eaten: <strong>+10 points</strong></li>
                  <li>• Speed increases as you score higher</li>
                  <li>• High score is saved locally</li>
                </ul>
              </div>

              <div className="bg-blue-50 rounded-lg p-4 border border-blue-100">
                <h4 className="text-blue-800 font-semibold mb-2">Tips</h4>
                <ul className="space-y-1 text-blue-700 text-sm">
                  <li>• Plan your turns ahead to avoid trapping yourself</li>
                  <li>• Don't make quick consecutive turns</li>
                  <li>• Use the edges strategically to corner the food</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
