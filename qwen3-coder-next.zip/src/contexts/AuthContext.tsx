import { createContext, useContext, ReactNode, useState, useEffect, useCallback } from 'react'
import { User, AuthCredentials, AuthResponse } from '../types/auth'

// 간단한 인증 서비스 (직접 구현)
const STORAGE_KEY = 'user'

function getStoredUser(): User | null {
  const stored = localStorage.getItem(STORAGE_KEY)
  if (!stored) return null
  try {
    return JSON.parse(stored) as User
  } catch {
    return null
  }
}

function storeUser(user: User): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(user))
}

function clearUser(): void {
  localStorage.removeItem(STORAGE_KEY)
}

async function authenticate(credentials: AuthCredentials): Promise<AuthResponse> {
  if (!credentials.email || !credentials.password) {
    return { success: false, error: 'Email and password are required' }
  }

  if (credentials.password.length < 6) {
    return { success: false, error: 'Password must be at least 6 characters' }
  }

  await new Promise((resolve) => setTimeout(resolve, 500))

  const isEmailValid = credentials.email.includes('@')
  const isPasswordValid = credentials.password.length >= 6

  if (isEmailValid && isPasswordValid) {
    const name = credentials.email.split('@')[0]
    const user: User = {
      id: '1',
      name: name.charAt(0).toUpperCase() + name.slice(1),
      email: credentials.email,
      avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=3b82f6&color=fff`,
    }
    storeUser(user)
    return { success: true, user }
  }

  return { success: false, error: 'Invalid credentials' }
}

interface AuthContextType {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  error: string | null
  login: (email: string, password: string) => Promise<boolean>
  logout: () => Promise<void>
  setError: (error: string | null) => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const storedUser = getStoredUser()
    setUser(storedUser)
    setIsLoading(false)
  }, [])

  const login = useCallback(async (email: string, password: string): Promise<boolean> => {
    setError(null)

    const result = await authenticate({ email, password })

    if (result.success && result.user) {
      setUser(result.user)
      return true
    }

    setError(result.error || 'Login failed')
    return false
  }, [])

  const logout = useCallback(async (): Promise<void> => {
    await clearUser()
    setUser(null)
  }, [])

  return (
    <AuthContext.Provider value={{ user, isAuthenticated: !!user, isLoading, error, login, logout, setError }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuthContext() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuthContext must be used within an AuthProvider')
  }
  return context
}
