/// <reference types="vite/client" />

declare module '*.css' {
  interface CSSModules {
    [className: string]: string
  }
  const classes: CSSModules
  export default classes
}
