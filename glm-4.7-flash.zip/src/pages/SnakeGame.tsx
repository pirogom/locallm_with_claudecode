import React, { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';

export const SnakeGame: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const startGameRef = useRef<(() => void) | null>(null);
  const [gameStarted, setGameStarted] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);

  // 게임 상태를 useRef로 관리하여 리렌더링 방지
  const gameRef = useRef({
    snake: [{ x: 10, y: 10 }],
    food: { x: 15, y: 15 },
    dx: 1, // 처음에는 오른쪽으로 이동
    dy: 0,
    gameLoop: null as number | null,
  });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const gridSize = 20;
    const tileCount = canvas.width / gridSize;

    const drawGame = () => {
      const { snake, food } = gameRef.current;

      // 배경
      ctx.fillStyle = '#1a1a2e';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // 스네이크
      ctx.fillStyle = '#4ade80';
      snake.forEach((segment, index) => {
        ctx.fillStyle = index === 0 ? '#22c55e' : '#4ade80';
        ctx.fillRect(
          segment.x * gridSize + 1,
          segment.y * gridSize + 1,
          gridSize - 2,
          gridSize - 2
        );
      });

      // 음식
      ctx.fillStyle = '#ef4444';
      ctx.beginPath();
      ctx.arc(
        food.x * gridSize + gridSize / 2,
        food.y * gridSize + gridSize / 2,
        gridSize / 2 - 2,
        0,
        2 * Math.PI
      );
      ctx.fill();
    };

    const moveSnake = () => {
      const { dx, dy, snake } = gameRef.current;

      if (dx === 0 && dy === 0) return;

      const head = { x: snake[0].x + dx, y: snake[0].y + dy };

      // 벽 충돌 확인
      if (head.x < 0 || head.x >= tileCount || head.y < 0 || head.y >= tileCount) {
        setGameOver(true);
        setGameStarted(false);
        if (gameRef.current.gameLoop) {
          clearInterval(gameRef.current.gameLoop);
          gameRef.current.gameLoop = null;
        }

        if (score > highScore) {
          setHighScore(score);
        }
        return;
      }

      // 자기 충돌 확인
      if (snake.some(segment => segment.x === head.x && segment.y === head.y)) {
        setGameOver(true);
        setGameStarted(false);
        if (gameRef.current.gameLoop) {
          clearInterval(gameRef.current.gameLoop);
          gameRef.current.gameLoop = null;
        }

        if (score > highScore) {
          setHighScore(score);
        }
        return;
      }

      const newSnake = [head, ...snake];
      gameRef.current.snake = newSnake;

      // 음식 먹기
      const { food } = gameRef.current;
      if (head.x === food.x && head.y === food.y) {
        setScore(prev => prev + 10);
        spawnFood();
      } else {
        newSnake.pop();
      }
    };

    const spawnFood = () => {
      const newFood = {
        x: Math.floor(Math.random() * tileCount),
        y: Math.floor(Math.random() * tileCount),
      };
      gameRef.current.food = newFood;
    };

    const startGame = () => {
      gameRef.current.snake = [{ x: 10, y: 10 }];
      gameRef.current.dx = 1; // 오른쪽으로 시작
      gameRef.current.dy = 0;
      const newScore = 0;
      spawnFood();
      setScore(newScore);
      setGameOver(false);
      setGameStarted(true);
    };

    startGameRef.current = startGame;

    const keyDownEvent = (e: KeyboardEvent) => {
      if (!gameStarted && !gameOver) {
        setGameStarted(true);
      }

      switch (e.key) {
        case 'ArrowUp':
        case 'w':
        case 'W':
          if (gameRef.current.dy !== 1) { gameRef.current.dx = 0; gameRef.current.dy = -1; }
          e.preventDefault();
          break;
        case 'ArrowDown':
        case 's':
        case 'S':
          if (gameRef.current.dy !== -1) { gameRef.current.dx = 0; gameRef.current.dy = 1; }
          e.preventDefault();
          break;
        case 'ArrowLeft':
        case 'a':
        case 'A':
          if (gameRef.current.dx !== 1) { gameRef.current.dx = -1; gameRef.current.dy = 0; }
          e.preventDefault();
          break;
        case 'ArrowRight':
        case 'd':
        case 'D':
          if (gameRef.current.dx !== -1) { gameRef.current.dx = 1; gameRef.current.dy = 0; }
          e.preventDefault();
          break;
      }
    };

    document.addEventListener('keydown', keyDownEvent);

    drawGame();

    const gameLoopInterval = 100;

    // 게임 시작 시 루프 시작
    if (gameStarted && !gameOver) {
      gameRef.current.gameLoop = window.setInterval(() => {
        moveSnake();
        drawGame();
      }, gameLoopInterval);
    }

    return () => {
      if (gameRef.current.gameLoop) {
        clearInterval(gameRef.current.gameLoop);
        gameRef.current.gameLoop = null;
      }
      document.removeEventListener('keydown', keyDownEvent);
    };
  }, [gameStarted, gameOver]); // gameStarted와 gameOver 변경 시 재실행

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center p-4">
      <div className="max-w-2xl w-full">
        <div className="text-center mb-6">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">🐍 Snake Game</h1>
          <p className="text-gray-600">스네이크 게임을 즐겨보세요!</p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex justify-between items-center mb-4">
            <div>
              <span className="text-gray-600">Score:</span>
              <span className="text-2xl font-bold text-gray-900 ml-2">{score}</span>
            </div>
            <div>
              <span className="text-gray-600">High Score:</span>
              <span className="text-2xl font-bold text-yellow-600 ml-2">{highScore}</span>
            </div>
          </div>

          <canvas
            ref={canvasRef}
            width={400}
            height={400}
            className="border-2 border-gray-300 rounded-lg mx-auto block"
          />

          {gameOver && (
            <div className="mt-4 text-center">
              <p className="text-xl font-bold text-red-600 mb-2">Game Over!</p>
              <div className="flex gap-4 justify-center">
                <button
                  onClick={startGameRef.current || (() => {})}
                  className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                >
                  Play Again
                </button>
                <Link
                  to="/login"
                  className="px-6 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
                >
                  Back to Login
                </Link>
              </div>
            </div>
          )}

          {!gameStarted && !gameOver && (
            <div className="mt-4 text-center">
              <button
                onClick={startGameRef.current || (() => {})}
                className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                Start Game
              </button>
            </div>
          )}
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4">게임 규칙</h2>
          <ul className="space-y-2 text-gray-700">
            <li className="flex items-start">
              <span className="text-green-600 mr-2">•</span>
              <span>뱀을 움직여 빨간색 사과를 먹으세요</span>
            </li>
            <li className="flex items-start">
              <span className="text-green-600 mr-2">•</span>
              <span>벽에 부딪히거나 자기 몸에 닿으면 게임 오버입니다</span>
            </li>
            <li className="flex items-start">
              <span className="text-green-600 mr-2">•</span>
              <span>사과를 먹을 때마다 점수가 10점씩 증가합니다</span>
            </li>
          </ul>

          <h2 className="text-xl font-bold text-gray-900 mt-6 mb-4">컨트롤</h2>
          <ul className="space-y-2 text-gray-700">
            <li className="flex items-start">
              <span className="text-blue-600 mr-2">•</span>
              <span><strong>방향키 (↑ ↓ ← →)</strong> 또는 <strong>(W A S D)</strong>로 뱀을 조종하세요</span>
            </li>
            <li className="flex items-start">
              <span className="text-blue-600 mr-2">•</span>
              <span>게임 시작 후 바로 방향키를 누르세요</span>
            </li>
          </ul>

          <div className="mt-6">
            <Link
              to="/login"
              className="inline-block px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Back to Login
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};
