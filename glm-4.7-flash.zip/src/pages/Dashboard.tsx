import React from 'react';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/common/Button';
import Layout from '../components/common/Layout';
import { Link } from 'react-router-dom';

export const Dashboard: React.FC = () => {
  const { user, logout } = useAuth();

  if (!user) {
    return null; // 보호된 라우트에서 처리
  }

  return (
    <Layout>
      <div className="space-y-6">
        <div className="bg-white rounded-lg shadow-md p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-6">
            Welcome, {user.username}!
          </h1>

          <div className="bg-gray-50 rounded-lg p-6 mb-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">
              Dashboard Information
            </h2>
            <div className="space-y-2">
              <p className="text-gray-700">
                <strong>User ID:</strong> {user.id}
              </p>
              <p className="text-gray-700">
                <strong>Username:</strong> {user.username}
              </p>
              <p className="text-gray-700">
                <strong>Email:</strong> {user.email || 'Not set'}
              </p>
              <p className="text-gray-700">
                <strong>Token:</strong> {user.token.substring(0, 20)}...
              </p>
            </div>
          </div>

          <div className="flex gap-4">
            <Link to="/profile">
              <Button variant="primary">
                View Profile
              </Button>
            </Link>
            <Button variant="secondary" onClick={() => alert('Settings coming soon!')}>
              Settings
            </Button>
            <Button variant="danger" onClick={logout}>
              Logout
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Stats Overview
            </h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                <span className="text-gray-700">Total Users</span>
                <span className="text-2xl font-bold text-blue-600">1,234</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                <span className="text-gray-700">Active Sessions</span>
                <span className="text-2xl font-bold text-green-600">567</span>
              </div>
              <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                <span className="text-gray-700">Revenue</span>
                <span className="text-2xl font-bold text-purple-600">$12,345</span>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Recent Activity
            </h3>
            <div className="space-y-3">
              <div className="flex items-center p-3 bg-gray-50 rounded">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-3"></div>
                <span className="text-gray-700">User login successful</span>
              </div>
              <div className="flex items-center p-3 bg-gray-50 rounded">
                <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
                <span className="text-gray-700">Profile updated</span>
              </div>
              <div className="flex items-center p-3 bg-gray-50 rounded">
                <div className="w-2 h-2 bg-yellow-500 rounded-full mr-3"></div>
                <span className="text-gray-700">Settings changed</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};
