import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { AuthContextValue, AuthenticatedUser } from './types';
import { AuthService } from '../services/authService';

const authService = new AuthService();

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthenticatedUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAuth = () => {
      setUser(authService.getUser());
      setLoading(false);
    };

    checkAuth();
  }, []);

  const login = async (username: string, password: string) => {
    try {
      const credentials = { username, password };
      await authService.login(credentials);
      setUser(authService.getUser());
    } catch (error) {
      throw error;
    }
  };

  const logout = () => {
    authService.logout();
    setUser(null);
  };

  const updateUserProfile = async (_firstName: string, _lastName: string, email: string) => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    try {
      setUser({
        ...user,
        email,
      });

      localStorage.setItem('auth_token', user.token);
    } catch (error) {
      throw error;
    }
  };

  return (
    <AuthContext.Provider value={{ user, isAuthenticated: !!user, login, logout, loading, updateUserProfile }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextValue => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
