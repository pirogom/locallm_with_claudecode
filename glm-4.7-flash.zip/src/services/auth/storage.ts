export interface TokenStorage {
  saveToken(token: string): void;
  getToken(): string | null;
  removeToken(): void;
  clear(): void;
}

export class LocalStorage implements TokenStorage {
  private readonly TOKEN_KEY = 'auth_token';

  saveToken(token: string): void {
    if (typeof window !== 'undefined') {
      localStorage.setItem(this.TOKEN_KEY, token);
    }
  }

  getToken(): string | null {
    if (typeof window !== 'undefined') {
      return localStorage.getItem(this.TOKEN_KEY);
    }
    return null;
  }

  removeToken(): void {
    if (typeof window !== 'undefined') {
      localStorage.removeItem(this.TOKEN_KEY);
    }
  }

  clear(): void {
    if (typeof window !== 'undefined') {
      localStorage.clear();
    }
  }
}
