import { LoginCredentials, AuthenticatedUser, InvalidCredentialsError } from './auth';

export class AuthService {
  async login(credentials: LoginCredentials): Promise<AuthenticatedUser> {
    await new Promise((resolve) => setTimeout(resolve, 1000));

    if (credentials.username === 'admin' && credentials.password === '1234') {
      return {
        id: '1',
        username: 'admin',
        email: 'admin@example.com',
        token: 'mock-jwt-token-12345',
      };
    }

    throw new InvalidCredentialsError();
  }

  logout(): void {
    localStorage.removeItem('auth_token');
  }

  isAuthenticated(): boolean {
    return !!localStorage.getItem('auth_token');
  }

  getUser(): AuthenticatedUser | null {
    const token = localStorage.getItem('auth_token');
    if (!token) {
      return null;
    }

    return {
      id: '1',
      username: 'admin',
      email: 'admin@example.com',
      token,
    };
  }
}
