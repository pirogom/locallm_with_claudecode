import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, Link } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import ProfilePage from './pages/ProfilePage';
import SnakeGamePage from './pages/SnakeGamePage';

const Nav = () => (
  <nav style={{ padding: '10px', borderBottom: '1px solid #ccc', display: 'flex', gap: '10px' }}>
    <Link to="/dashboard">Dashboard</Link>
    <Link to="/profile">Profile</Link>
    <Link to="/snake">Snake Game</Link>
    <Link to="/login">Login</Link>
  </nav>
);

const App: React.FC = () => (
  <AuthProvider>
    <Router>
      <Nav />
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/snake" element={<SnakeGamePage />} />
        <Route path="/dashboard" element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} />
        <Route path="/profile" element={<ProtectedRoute><ProfilePage /></ProtectedRoute>} />
        <Route path="/" element={<Navigate to="/dashboard" />} />
      </Routes>
    </Router>
  </AuthProvider>
);

export default App;
