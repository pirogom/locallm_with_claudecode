import React from 'react';
import { useAuth } from '../context/AuthContext';

const DashboardPage: React.FC = () => {
  const { user, logout } = useAuth();

  return (
    <div style={{ padding: '20px' }}>
      <h1>Dashboard</h1>
      <p>Welcome, {user?.name} ({user?.email})!</p>
      <button onClick={logout}>Logout</button>
    </div>
  );
};

export default DashboardPage;
