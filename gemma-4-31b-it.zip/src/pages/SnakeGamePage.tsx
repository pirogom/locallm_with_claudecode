import React, { useState, useEffect, useCallback } from 'react';

const GRID_SIZE = 20;
const INITIAL_SNAKE = [{ x: 10, y: 10 }];
const INITIAL_FOOD = { x: 5, y: 5 };
const SPEED = 150;

const SnakeGamePage: React.FC = () => {
  const [snake, setSnake] = useState(INITIAL_SNAKE);
  const [food, setFood] = useState(INITIAL_FOOD);
  const [direction, setDirection] = useState({ x: 0, y: -1 });
  const [gameOver, setGameOver] = useState(false);
  const [score, setScore] = useState(0);

  const generateFood = useCallback(() => {
    return {
      x: Math.floor(Math.random() * GRID_SIZE),
      y: Math.floor(Math.random() * GRID_SIZE),
    };
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'ArrowUp': if (direction.y === 0) setDirection({ x: 0, y: -1 }); break;
        case 'ArrowDown': if (direction.y === 0) setDirection({ x: 0, y: 1 }); break;
        case 'ArrowLeft': if (direction.x === 0) setDirection({ x: -1, y: 0 }); break;
        case 'ArrowRight': if (direction.x === 0) setDirection({ x: 1, y: 0 }); break;
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [direction]);

  useEffect(() => {
    if (gameOver) return;

    const moveSnake = setInterval(() => {
      setSnake((prevSnake) => {
        const newHead = {
          x: (prevSnake[0].x + direction.x + GRID_SIZE) % GRID_SIZE,
          y: (prevSnake[0].y + direction.y + GRID_SIZE) % GRID_SIZE,
        };

        if (prevSnake.some(seg => seg.x === newHead.x && seg.y === newHead.y)) {
          setGameOver(true);
          return prevSnake;
        }

        const newSnake = [newHead, ...prevSnake];
        if (newHead.x === food.x && newHead.y === food.y) {
          setScore(s => s + 1);
          setFood(generateFood());
        } else {
          newSnake.pop();
        }
        return newSnake;
      });
    }, SPEED);

    return () => clearInterval(moveSnake);
  }, [direction, food, gameOver, generateFood]);

  const resetGame = () => {
    setSnake(INITIAL_SNAKE);
    setFood(INITIAL_FOOD);
    setDirection({ x: 0, y: -1 });
    setGameOver(false);
    setScore(0);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '20px', fontFamily: 'monospace' }}>
      <h1>🐍 Snake Game</h1>
      <div style={{ marginBottom: '10px', fontSize: '20px' }}>Score: {score}</div>
      
      <div style={{ 
        position: 'relative', 
        width: GRID_SIZE * 20, 
        height: GRID_SIZE * 20, 
        backgroundColor: '#eee', 
        border: '2px solid #333' 
      }}>
        {snake.map((seg, i) => (
          <div key={i} style={{ 
            position: 'absolute', 
            left: seg.x * 20, 
            top: seg.y * 20, 
            width: 18, 
            height: 18, 
            backgroundColor: i === 0 ? 'green' : 'darkgreen',
            borderRadius: '2px'
          }} />
        ))}
        <div style={{ 
          position: 'absolute', 
          left: food.x * 20, 
          top: food.y * 20, 
          width: 18, 
          height: 18, 
          backgroundColor: 'red', 
          borderRadius: '50%' 
        }} />
        {gameOver && (
          <div style={{ 
            position: 'absolute', 
            top: 0, left: 0, right: 0, bottom: 0, 
            backgroundColor: 'rgba(0,0,0,0.5)', 
            color: 'white', 
            display: 'flex', 
            flexDirection: 'column', 
            justifyContent: 'center', 
            alignItems: 'center' 
          }}>
            <h2>GAME OVER</h2>
            <button onClick={resetGame} style={{ padding: '10px 20px', cursor: 'pointer' }}>Restart</button>
          </div>
        )}
      </div>

      <div style={{ marginTop: '20px', padding: '15px', backgroundColor: '#f9f9f9', border: '1px solid #ddd', borderRadius: '8px', maxWidth: '400px' }}>
        <h3>📖 Rules & Controls</h3>
        <ul style={{ lineHeight: '1.6' }}>
          <li><strong>Objective:</strong> Eat the red food to grow and increase your score.</li>
          <li><strong>Lose Condition:</strong> Game ends if you crash into your own tail.</li>
          <li><strong>Controls:</strong> Use the <strong>Arrow Keys</strong> (↑, ↓, ←, →) to change direction.</li>
          <li><strong>Note:</strong> The snake can pass through walls (wrapping around).</li>
        </ul>
      </div>
    </div>
  );
};

export default SnakeGamePage;
